#!/usr/bin/env bash
# This file will contain functions related to gathering stats and displaying it for agent
# Agent will have to call mmp-stats.sh which will contain triggers for configuration files and etc.
# Do not add anything static in this file
GPU_COUNT=$1
LOG_FILE=$2
cd `dirname $0`

api_stats=$(curl -s 'http://localhost:44001/stats')

if [[ $? -ne 0 || -z $api_stats ]]; then
    echo -e "Failed to read $miner from localhost:44001"
else
    stats_array=()
    for value in $api_stats; do stats_array+=($value); done

    hash=${stats_array[0]}
    ver=${stats_array[2]}
    acc=${stats_array[3]}
    rej=${stats_array[4]}
    units="hs"

    busid=( "cpu" )

    json_busid="["
    for element in "${busid[@]}"; do
        if [ -n "$element" ]; then
            json_busid+="\"$element\", "
        fi
    done
    json_busid="${json_busid%, }"
    json_busid+="]"

    stats=$(jq -nc \
            --argjson hash "$(echo ${hash[@]} | tr " " "\n" | jq -cs '.')" \
            --argjson busid "$json_busid" \
            --arg units "$units" \
            --arg ac "$acc" --arg inv "0" --arg rj "$rej" \
            --arg miner_version "$ver" \
            --arg miner_name "deroluna" \
        '{$busid, $hash, $units, air: [$ac, $inv, $rj], miner_name: $miner_name, miner_version: $miner_version}')

fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
echo $stats
